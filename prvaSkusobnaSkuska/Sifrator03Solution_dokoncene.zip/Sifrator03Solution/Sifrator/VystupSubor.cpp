#include <fstream>
#include "VystupSubor.h"

VystupSubor::VystupSubor(const unsigned char* pMenoSuboru)
	:aMenoSuboru(pMenoSuboru ? (char*)pMenoSuboru : "")
{
	//aMenoSuboru = (char*)pMenoSuboru;
}

void VystupSubor::Zapis(const unsigned char* text)
{
	if (!text) return;
	int dlzka = strlen((char*)text);
	if (dlzka)
	{
		if (!aMenoSuboru.empty())
		{
			FILE* f{ fopen(aMenoSuboru.c_str(),"wb") };
			if (f)
			{
				fwrite(text, dlzka, 1, f);
				fclose(f);
			}
		}
	}
}

void VystupSubor::ZapisStream(const unsigned char* text)
{
	if (!text) return;
	int dlzka = strlen((char*)text);
	if (dlzka)
	{
		ofstream f{ aMenoSuboru, ios::binary };
		if (f.is_open())
		{
			//f.write((char*)text, dlzka);
			f << text;
		}
	}
}

#include "Help.h"
#include "Vystup.h"

void Help::Napoveda()
{
	Vystup().VypisNaKonzolu((unsigned char*)
		"\nsifrator TYP_CINNOSTI HESLO VSTUPNY_SUBOR [TYP_VYPISU] [VYSTUPNY_SUBOR]\n\n"
		"   TYP_CINNOSTI:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...napoveda\n"
		"   HESLO: max. 8 znakov\n"
		"   VSTUPNY_SUBOR: meno vstupneho suboru\n"
		"   TYP_VYPISU:\n"
		"      s...ulozenie do suboru\n"
		"      d...vypis na displej\n"
		"   VYSTUPNY_SUBOR: meno vystupneho suboru\n\n"
	);
}

#pragma once

const unsigned int DLZKA_HESLA = 8;

union Heslo
{
private:
	char aHeslo[DLZKA_HESLA];
	long long aNasada;
public:
	Heslo(const char* pHeslo);
	~Heslo() = default;
	unsigned int DajNasadu();
};


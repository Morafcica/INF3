#include "Vstup.h"
#include "pomFunkcie.h"
#include <cstdio>

Vstup::Vstup(const unsigned char* pMenoSuboru)
{
	//aMenoSuboru = (unsigned char*)pMenoSuboru; // toto nesmieme!!!
	aMenoSuboru = AlokujKopiruj(pMenoSuboru);
}

Vstup::Vstup(const Vstup& zdroj)
{
	aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
}

Vstup& Vstup::operator=(const Vstup& zdroj)
{
	if (this != &zdroj)
	{
		this->~Vstup();
		aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
	}
	return *this;
}

Vstup::~Vstup()
{
	delete[] aMenoSuboru;
}

unsigned char* Vstup::CitajSubor() const
{
	int dlzka = DlzkaSuboru();
	if (dlzka > 0)
	{
		FILE* f{ fopen((char*)aMenoSuboru, "rb") };
		unsigned char* text = new unsigned char[dlzka + 1];
		if (text)
		{
			fread(text, dlzka, 1, f);
			text[dlzka] = 0;
			fclose(f);
			return text;
		}
	}
	return nullptr;
}

int Vstup::DlzkaSuboru() const
{
	if (aMenoSuboru && *aMenoSuboru)
	{
		FILE* f{ fopen((char*)aMenoSuboru, "rb") }; // mod binarneho citania
		if (f)
		{
			fseek(f, 0, SEEK_END);
			int dlzka = ftell(f);
			fclose(f);
			return dlzka;
		}
	}
	return 0;
}

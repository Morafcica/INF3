#pragma once

char* AlokujKopiruj(const char* zdrojText);
unsigned char* AlokujKopiruj(const unsigned char* zdrojText);

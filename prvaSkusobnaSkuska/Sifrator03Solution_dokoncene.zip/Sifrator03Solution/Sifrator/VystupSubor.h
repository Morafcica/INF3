#pragma once
#include <string>

using namespace std;

class VystupSubor
{
private:
	string aMenoSuboru;
public:
	VystupSubor(const unsigned char* pMenoSuboru);
	~VystupSubor() = default;
	void Zapis(const unsigned char* text);
	void ZapisStream(const unsigned char* text);
};


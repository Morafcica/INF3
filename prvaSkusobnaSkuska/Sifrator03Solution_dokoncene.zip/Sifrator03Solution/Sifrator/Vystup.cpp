#include "Vystup.h"
#include "VystupSubor.h"
#include "VystupKonzola.h"

void Vystup::Zapis(const unsigned char* text, const unsigned char* menoSuboru)
{
	if (text && *text)
	{
		if (menoSuboru && *menoSuboru)
			VystupSubor(menoSuboru).ZapisStream(text);
		else
			VystupKonzola().Zapis((unsigned char*)text);
	}
}

void Vystup::UlozDoSuboru(const unsigned char* text, const unsigned char* menoSuboru)
{
	if (menoSuboru && *menoSuboru)
		Zapis(text, menoSuboru);
}

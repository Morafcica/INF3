#include "Testy.h"
#include "Heslo.h"
#include "Koder.h"
#include <string.h>
#include "VystupKonzola.h"
#include "Vstup.h"
#include "VystupSubor.h"

bool Testy::Testuj()
{
	Heslo h("abc123");
	Koder koder;
	unsigned char* sifrovanyText =
		koder.Koduj((unsigned char*)"abc123",
			(unsigned char*)"testovanie kodera");
	unsigned dlzka = strlen((char*)sifrovanyText);
	VystupKonzola().Zapis(sifrovanyText);
	//test dekodovania
	Koder* dekoder = new Koder();
	unsigned char* povodnyText = dekoder->Dekoduj((unsigned char*)"abc123", sifrovanyText);
	VystupKonzola konzola;
	konzola.Zapis((unsigned char*)"\n");
	konzola.Zapis(povodnyText);
	if (povodnyText)
		delete[] povodnyText;
	povodnyText = Vstup((unsigned char*)"heslo.h").CitajSubor();

	const VystupKonzola konzolaConst;
	konzolaConst.Zapis(povodnyText);

	VystupSubor((unsigned char*)"sifrator.test1").Zapis(povodnyText);
	VystupSubor((unsigned char*)"sifrator.test2").ZapisStream(povodnyText);
	
	delete[] povodnyText;
	delete dekoder;
	delete[] sifrovanyText;
	return true;
}

#pragma once
class Help
{
public:
	void Napoveda();
};


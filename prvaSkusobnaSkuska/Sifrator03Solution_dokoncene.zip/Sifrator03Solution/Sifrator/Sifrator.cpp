#include "Sifrator.h"
#include "Help.h"
#include <cctype>
#include "pomFunkcie.h"
#include "Vstup.h"
#include "Koder.h"
#include "Vystup.h"

Sifrator::Sifrator(int pocetParametrov, char* parametre[])
{
	if (pocetParametrov > 0)
		aCinnost = tolower(parametre[0][0]);
	if (pocetParametrov > 1)
		aHeslo = AlokujKopiruj(parametre[1]);
	if (pocetParametrov > 2)
		aMenoVstupnehoSuboru = AlokujKopiruj(parametre[2]);
	if (pocetParametrov > 3)
		aKonzola = *parametre[3] == 's' ? false : true;
	if (pocetParametrov > 4)
		aMenoVystupnehoSuboru = AlokujKopiruj(parametre[4]);
	aCinnost = (aCinnost != 's' && aCinnost != 'd' && aCinnost != 'h') ? 'h' : aCinnost;
	if (!(aHeslo && *aHeslo)) aCinnost = 'h';
	if (!(aMenoVstupnehoSuboru && *aMenoVstupnehoSuboru)) aCinnost = 'h';
	if (aKonzola) aMenoVystupnehoSuboru = nullptr;
}

Sifrator::~Sifrator()
{
	delete[] aMenoVystupnehoSuboru;
	delete[] aMenoVstupnehoSuboru;
	delete[] aHeslo;
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		Help().Napoveda();
	else
	{
		unsigned char* zdrojText = Vstup((unsigned char*)aMenoVstupnehoSuboru).CitajSubor();
		if (zdrojText)
		{
			unsigned char* cielText = aCinnost == 's' ?
				Koder().Koduj((unsigned char*)aHeslo, zdrojText) :
				Koder().Dekoduj((unsigned char*)aHeslo, zdrojText);
			if (cielText)
			{
				Vystup().Zapis(cielText, (unsigned char*)aMenoVystupnehoSuboru);
				delete[] cielText;
			}
			delete[] zdrojText;
		}
		else
			Help().Napoveda();
	}
}

#include "pomFunkcie.h"
#include <cstring>

char* AlokujKopiruj(const char* zdrojText)
{
	if (zdrojText)
	{
		int dlzka = (int)strlen(zdrojText);
		char* cielText = new  char[dlzka + 1];
		if (cielText)
		{
			strcpy(cielText, zdrojText);
			return cielText;
		}
	}
	return nullptr;
}

unsigned char* AlokujKopiruj(const unsigned char* zdrojText)
{
	if (zdrojText)
	{
		int dlzka = (int)strlen((char*)zdrojText);
		unsigned char* cielText = new unsigned char[dlzka + 1];
		if (cielText)
		{
			strcpy((char*)cielText, (char*)zdrojText);
			return cielText;
		}
	}
	return nullptr;
}

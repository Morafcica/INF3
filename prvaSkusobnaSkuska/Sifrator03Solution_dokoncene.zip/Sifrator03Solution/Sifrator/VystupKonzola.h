#pragma once
#include <iostream>

class VystupKonzola
{
public:
	void Zapis(unsigned char* text) const
	{
		std::cout << text;
	}
};


#pragma once
class Vystup
{
public:
	// parameter menoSuboru ma imlicitnu hodnotu nullptr
	void Zapis(const unsigned char* text, const unsigned char* menoSuboru = nullptr);
	void UlozDoSuboru(const unsigned char* text, const unsigned char* menoSuboru);
	void VypisNaKonzolu(const unsigned char* text)
	{
		Zapis(text);
	}
};


#include "Heslo.h"
#include <cstring>

Heslo::Heslo(const char* pHeslo)
{
	// priamy pristup do pamati
	memset(aHeslo, 0, DLZKA_HESLA);
	if (pHeslo != nullptr && *pHeslo != 0)
	{
		unsigned dlzka = (unsigned)strlen(pHeslo);
		dlzka = dlzka > DLZKA_HESLA ? DLZKA_HESLA : dlzka;
		memmove(aHeslo, pHeslo, dlzka);
		//char aaa[4]{ "abc" };
	}
}

unsigned int Heslo::DajNasadu()
{
	unsigned nasada1 = aNasada & 0x00000000ffffffff;
	unsigned nasada2 = (aNasada >> 32) & 0x00000000ffffffff;
	return nasada1 + nasada2;
}

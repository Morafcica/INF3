#include "MemLeak.h"
//#define TESTY
#ifdef TESTY
#include "Testy.h"
#endif // TESTY
#include "Sifrator.h"
#include "VystupKonzola.h"

int main(int argc, char* argv[])
{
	bool ok{ true };
#ifdef TESTY
	Testy t;
	ok = t.Testuj();
#endif // TESTY
	if (ok)
	{
		Sifrator(argc-1, &argv[1]).Start();
	}
	else
	{
		VystupKonzola().Zapis((unsigned char*)"Testy skoncili chybou\n");
	}
	//_CrtDumpMemoryLeaks();
	return 0;
}
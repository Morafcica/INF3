#pragma once
class Testy
{
public:
	bool Testuj();
};


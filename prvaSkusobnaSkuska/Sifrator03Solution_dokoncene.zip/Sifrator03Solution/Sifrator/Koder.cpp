#include "Koder.h"
#include "Heslo.h"
#include <cstdlib>
#include <cstring>
#include <cstdio>

unsigned char* Koder::Koduj(const unsigned char* pHeslo, const unsigned char* text)
{
	if (text == nullptr || *text == 0) return (unsigned char*)text;
	PripravTabulku(pHeslo);
	unsigned dlzkaTextu = (unsigned)strlen((char*)text);
	// pole kodovanyText nie je retazec
	unsigned char* kodovanyText = new unsigned char[dlzkaTextu];
	if (kodovanyText)
	{
		for (unsigned i = 0; i < dlzkaTextu; i++)
			kodovanyText[i] = aKodTabulka[text[i]];
		// vystupny retazec, alokuje aj miesto pre koncovy znak '\0'
		unsigned char* sifrovanyText = new unsigned char[3 * dlzkaTextu + 1];
		if (sifrovanyText)
		{
			unsigned k{0};
			for (unsigned i = 0; i < dlzkaTextu; i++)
			{
				char buffer[4]{};
				sprintf(buffer, "%03u", kodovanyText[i]);
				memmove(&sifrovanyText[k], buffer, 3);
				k += 3;
			}
			sifrovanyText[k] = '\0';
			delete[] kodovanyText;

			return sifrovanyText;
		}
	}
	return nullptr;
}

unsigned char* Koder::Dekoduj(const unsigned char* pHeslo, const unsigned char* text)
{
	if (text == nullptr || *text == 0) return (unsigned char*)text;
	PripravTabulku(pHeslo);
	DekodujTabulku();
	unsigned dlzkaTextu = strlen((char*)text);
	unsigned char* kodovanyText = new unsigned char[dlzkaTextu / 3];
	if (kodovanyText)
	{
		char buffer[4]{};
		int i{}, k{};
		while (i<dlzkaTextu)
		{
			memmove(buffer, &text[i], 3);
			kodovanyText[k++] = atoi(buffer);
			i += 3;
		}
		unsigned char* dekodovanyText = new unsigned char[k+1];
		if (dekodovanyText)
		{
			for (unsigned i = 0; i < k; i++)
				dekodovanyText[i] = aKodTabulka[kodovanyText[i]];
			dekodovanyText[k] = 0;
			delete[] kodovanyText;
			return dekodovanyText;
		}
	}
	return nullptr;
}

void Koder::NaplnTabulku()
{
	for (unsigned i = 0; i < DLZKA_TABULKY; i++)
		aKodTabulka[i] = i;
}

void Koder::ZakodujTabulku(const unsigned char* pHeslo)
{
	unsigned int nasada = DajNasadu(pHeslo);
	srand(nasada);
	for (unsigned i = 0; i < DLZKA_TABULKY; i++)
	{
		int index = rand() % (DLZKA_TABULKY - i);
		Vymen(aKodTabulka[index], aKodTabulka[DLZKA_TABULKY - 1 - i]);
		//Vymen(&aKodTabulka[index], &aKodTabulka[DLZKA_TABULKY - 1 - i]);
	}
}

void Koder::PripravTabulku(const unsigned char* pHeslo)
{
	NaplnTabulku();
	ZakodujTabulku(pHeslo);
}

unsigned int Koder::DajNasadu(const unsigned char* pHeslo)
{
	//Heslo heslo((char*)pHeslo);
	//unsigned int nasada = heslo.DajNasadu();
	//return nasada;
	return Heslo((char*)pHeslo).DajNasadu();
}

void Koder::DekodujTabulku()
{
	unsigned char pomocnaTabulka[DLZKA_TABULKY]{};
	for (unsigned i = 0; i < DLZKA_TABULKY; i++)
		pomocnaTabulka[aKodTabulka[i]] = i;
	for (unsigned i = 0; i < DLZKA_TABULKY; i++)
		aKodTabulka[i] = pomocnaTabulka[i];
}

void Koder::Vymen(unsigned char* a, unsigned char* b)
{
	unsigned char pomocny{ *a };
	*a = *b;
	*b = pomocny;
}

void Koder::Vymen(unsigned char& a, unsigned char& b)
{
	unsigned char pomocny{ a };
	a = b;
	b = pomocny;
}

// prenos parametrov hodnotami, nepouzitelne pre nase potreby
void Vymen(char a, char b)
{
	char pomocny{ a };
	a = b;
	b = pomocny;
}
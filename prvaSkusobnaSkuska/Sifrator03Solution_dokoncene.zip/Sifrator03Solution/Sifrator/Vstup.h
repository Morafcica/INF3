#pragma once
class Vstup
{
private:
	unsigned char* aMenoSuboru{};
public:
	// konverzny konstruktor
	Vstup(const unsigned char* pMenoSuboru);
	// kopirovaci konstruktor 
	Vstup(const Vstup& zdroj);
	// operator priradenia
	Vstup& operator=(const Vstup& zdroj);
	~Vstup();
	// nacita obsah suboru. 
	// Funkcia alokuje retazec, treba po pouziti DELETOVAT!!!
	unsigned char* CitajSubor() const;
private:
	int DlzkaSuboru() const;
};

#pragma once

const unsigned int DLZKA_TABULKY = 256;

class Koder
{
private:
	unsigned char aKodTabulka[DLZKA_TABULKY]{};
public:
	Koder() = default;
	~Koder() = default;
	// POZOR! Vystupny retazec je alokovany vo fukcii a po jeho pouziti
	// je potrebne ho DELETOVAT!
	unsigned char* Koduj(const unsigned char* pHeslo, const unsigned char* text);
	// POZOR! Vystupny retazec je alokovany vo fukcii a po jeho pouziti
	// je potrebne ho DELETOVAT!
	unsigned char* Dekoduj(const unsigned char* pHeslo, const unsigned char* text);
private:
	// nastavi hodnoty prvkov na hodnoty indexov
	void NaplnTabulku();
	// premiesa tabulku pomocou generatora rand()
	void ZakodujTabulku(const unsigned char* pHeslo);
	void PripravTabulku(const unsigned char* pHeslo);
	unsigned int DajNasadu(const unsigned char* pHeslo);
	// v�mena indexov a hodn�t na t�chto indexoch
	void DekodujTabulku();
	// prenos parametrov pomocou smernikov
	void Vymen(unsigned char* a, unsigned char* b);
	// prenos parametrov pomocou odkazov
	void Vymen(unsigned char& a, unsigned char& b);
};


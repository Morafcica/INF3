#pragma once

//1. Typ po�adovanej �innosti : s � �ifrovanie, d � de�ifrovanie, h � help
//2. Heslo : max. 8 znakov
//4. Meno(vr�tane cesty) vstupn�ho s�boru
//3. Indik�tor v�pisu na konzolu(napr.znak c)
//5. Meno(vr�tane cesty) v�stupn�ho s�boru

class Sifrator
{
private:
	char aCinnost{'h'};
	char* aHeslo{};
	char* aMenoVstupnehoSuboru{};
	bool aKonzola{ true };
	char* aMenoVystupnehoSuboru{};
public:
	Sifrator(int pocetParametrov, char* parametre[]);
	// copy konstruktor je zakazany
	Sifrator(const Sifrator& zdroj) = delete;
	Sifrator& operator=(const Sifrator&) = delete;
	Sifrator(const Sifrator&& zdroj) = delete;
	Sifrator& operator=(const Sifrator&&) = delete;
	
	~Sifrator();

	// riadenie behu aplik�cie na z�klade vstupn�ch parametrov
	void Start();
};

